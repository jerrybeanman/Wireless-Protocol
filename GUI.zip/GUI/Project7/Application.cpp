

#define STRICT
#include "Application.h"

HWND hwnd;              // owner window
HANDLE fileReaderThread;
DWORD fileReaderID;
MSG Msg;

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hprevInstance,
	LPSTR lspszCmdParam, int nCmdShow) {

	// State - Build Window
	hDlg = CreateDialogParam(hInst, MAKEINTRESOURCE(IDD_DIALOG1), 0, WndProc, 0);
	ShowWindow(hDlg, nCmdShow);

	initFileOpener();
	/*
	SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)"one");
	SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)"three");
	SendMessage(GetDlgItem(hDlg, IDC_COMBO1), CB_ADDSTRING, 0, (LPARAM)"two");
	*/

	SendMessage (GetDlgItem (hDlg, IDC_READERFILE), EM_SETLIMITTEXT, (LPARAM)MAX_FILE, NULL);
	SendMessage (GetDlgItem (hDlg, IDC_WRITERFILE), EM_SETLIMITTEXT, (LPARAM)MAX_FILE, NULL);

	Initialize_Serial_Port();

	// State - Enter Comm param 
	Setup_Comm_Config();

	// State - Engine Read Thread Start
	Initialize_Read();

	while (GetMessage(&Msg, NULL, 0, 0)) {
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}

	return Msg.wParam;
}

INT_PTR CALLBACK WndProc (HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam) {

	switch (uMsg) {
		case WM_COMMAND:
			switch (LOWORD (wParam)) {
				case IDC_BUTTONOPEN:
					if (GetOpenFileName (&ofn) == TRUE)
						fileReaderThread = CreateThread (NULL, 0, createFileOpener, NULL, 0, &fileReaderID);
					loadFileToView(ofn.lpstrFile);
					
					break;
				case IDC_BUTTONSEND:
					Send_Data_Test ();
					//Test_Initialize_Write(NULL);
					break;
			}
			break;
		case WM_CLOSE:	// Terminate program
			PostQuitMessage (0);
			break;
		default:
			return false;
	}
	return 0;
}

