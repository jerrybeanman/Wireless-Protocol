#include "Global.h"
#include <iostream>

HANDLE hf;              // file handle
OPENFILENAME ofn;       // common dialog box structure
HWND hDlg;
char szFile[260];       // buffer for file name
int writerFileLines;
int readerFileLines;

DWORD WINAPI createFileOpener(LPVOID lpParam) {
	hf = CreateFile(ofn.lpstrFile,
		GENERIC_READ,
		0,
		(LPSECURITY_ATTRIBUTES)NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		(HANDLE)NULL);
	return 0;
}

void loadFileToView(LPSTR file) {
	int idx;
	std::string tmp;
	std::ifstream inputF(file);
	while (getline(inputF, tmp)) {
		tmp += "\n";
		idx = GetWindowTextLength(GetDlgItem(hDlg, IDC_EDIT3));
		SendMessage(GetDlgItem(hDlg, IDC_EDIT3), EM_SETSEL, (LPARAM)idx, (LPARAM)idx);
		SendMessage(GetDlgItem(hDlg, IDC_EDIT3), EM_REPLACESEL, 0, (LPARAM)(tmp.c_str()));
	}
	writerFileLines = SendMessage (GetDlgItem (hDlg, IDC_EDIT3), EM_GETLINECOUNT, NULL, NULL);
	inputF.close();
}

/*
This function is for UI testing.
It read all the lines in IDC_WRITERFILE and send them in fake packets sizes of
one line (not set size).
This function is just for testing, once packet reading is done, this is a useless function.
*/
void Send_Data_Test () {
	size_t i;
	//handle of box were sending to.
	HWND readFrom = GetDlgItem (hDlg, IDC_WRITERFILE);
	HWND sendTo = GetDlgItem (hDlg, IDC_READERFILE);
	
	for (i = 0; i < writerFileLines; i++) {
		addLine(&sendTo, getLine(&readFrom, i));
	}
}

void addLine (const HWND *box, std::string line) {
	int idx;
	idx = GetWindowTextLength (*box);
	SendMessage (*box, EM_SETSEL, (LPARAM)idx, (LPARAM)idx);
	SendMessage (*box, EM_REPLACESEL, 0, (LPARAM)(line.c_str ()));
}

std::string getLine (HWND *box, int line) {
	size_t len;
	TCHAR *tmp;
	len = SendMessage (*box, EM_LINELENGTH, SendMessage (*box, EM_LINEINDEX, line, 0), NULL);
	tmp = new TCHAR[len];
	SendMessage (*box, EM_GETLINE, line, (LPARAM)tmp);
	tmp[len] = '\0';
	return tmp;
}


void initFileOpener() {
	ZeroMemory(&ofn, sizeof(ofn));
	ofn.lStructSize = sizeof(ofn);
	ofn.hwndOwner = hDlg;
	ofn.lpstrFile = szFile;
	// Set lpstrFile[0] to '\0' so that GetOpenFileName does not 
	// use the contents of szFile to initialize itself.
	ofn.lpstrFile[0] = '\0';
	ofn.nMaxFile = sizeof(szFile);
	ofn.lpstrFilter = "All\0*.*\0Text\0*.TXT\0";
	ofn.nFilterIndex = 1;
	ofn.lpstrFileTitle = NULL;
	ofn.nMaxFileTitle = 0;
	ofn.lpstrInitialDir = NULL;
	ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;
}

// Display the Open dialog box. 


