#ifndef OPENFILE_H
#define OPENFILE_H
#define MAX_FILE	1000000

#include "Global.h"

DWORD WINAPI createFileOpener (LPVOID lpParam);
void initFileOpener ();
INT_PTR CALLBACK WndProc (HWND hDlg, UINT uMsg, WPARAM wParam, LPARAM lParam);
int WINAPI WinMain (HINSTANCE hInst, HINSTANCE hprevInstance,
	LPSTR lspszCmdParam, int nCmdShow);
void loadFileToView(LPSTR file);
void addLine (const HWND *box, std::string line);
void Send_Data_Test ();
std::string getLine (HWND *box, int line);

#endif
