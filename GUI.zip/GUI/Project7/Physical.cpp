#include "Physical.h"

// Reads any kind of data from the serial port :)
/*------------------------------------------------------------------------------------------------------------------
-- FUNCTION: Wait_For_Data
--
-- DATE: November 22, 2015
--
-- REVISIONS: (Date and Description)
--
-- DESIGNER: Ruoqi Jia
--
-- PROGRAMMER: Ruoqi Jia
--
-- INTERFACE: BOOL Wait_For_Data(	char	**str, 
--									DWORD	buffer_size, 
--									LPDWORD total_bytes_read, 
--									DWORD	TIMEOUT)
--					- char **str				: Buffer to store the content retrived by Read_File
--					- DWORD buffer_size			: The size of the buffer, has to be specified explicitly
--					- LPDWORD total_bytes_read	: total bytes actually read frmo the serial port, 
--							might be smaller than 516
--					- DWORD TIMEOUT				: Waiting time
--					- HANDLE lock				: basically pass in hRead_Lock if you're operating in 
--							Physical_Read.h, hWrite_Lock if in Physical_Write.h
--
-- RETURNS: TRUE if data read successfully, FALSE if timeout
--
-- NOTES:
--	Pretty much reads any kind of data from the serial port :)
----------------------------------------------------------------------------------------------------------------------*/
BOOL Wait_For_Data(
	char	**str, 
	DWORD	buffer_size, 
	DWORD	TIMEOUT)
{
	*str = new char[buffer_size];
	OVERLAPPED ovRead = { NULL };
	ovRead.hEvent = CreateEvent(NULL, FALSE, FALSE, EV_OVREAD);
	if (!Timeout(TIMEOUT))
	{
		OutputDebugString("Timeout\n");
		return FALSE;
	}
	OutputDebugString("Got Something back\n");
	ReadFile(hComm, *str, buffer_size, NULL, &ovRead);
	//PurgeComm(hComm, PURGE_RXCLEAR | PURGE_TXCLEAR);
	return TRUE;
}

/*------------------------------------------------------------------------------------------------------------------
-- FUNCTION: Wait_For_Data
--
-- DATE: November 22, 2015
--
-- REVISIONS: (Date and Description)
--
-- DESIGNER: Ruoqi Jia
--
-- PROGRAMMER: Ruoqi Jia
--
-- INTERFACE: VOID Send(char* msg, DWORD size, HANDLE lock)
--					- char *msg		: buffer to sent to the serial port
--					- DWORD size	: size of the buffer
--					- HANDLE lock	: basically pass in hRead_Lock if you're operating in 
--							Physical_Read.h, hWrite_Lock if in Physical_Write.h
--
-- RETURNS: VOID
--
-- NOTES:
--	 Send any kind of data to the serial port
----------------------------------------------------------------------------------------------------------------------*/

VOID Send(char* msg, DWORD size, HANDLE lock)
{
	COMSTAT cs;
	DWORD err;
	OVERLAPPED ovWrite = { NULL };
	ovWrite.hEvent = CreateEvent(NULL, FALSE, FALSE, EV_OVWRITE);
	// Lock this thread
	WaitForSingleObject(lock, INFINITE);

	WriteFile(hComm, msg, size, NULL, &ovWrite);
	// Release this thread
	ReleaseMutex(hWrite_Lock);
	CloseHandle(ovWrite.hEvent);
	ClearCommError(hComm, &err, &cs);
}

//
// check serial port data
//
BOOL Timeout(DWORD msec)
{
	COMSTAT cs;
	DWORD fdwCommMask;
	SetCommMask(hComm, EV_RXCHAR);
	OVERLAPPED OverLapped;
	memset((char *)&OverLapped, 0, sizeof(OVERLAPPED));
	OverLapped.hEvent = CreateEvent(NULL, TRUE, TRUE, 0);
	if (!WaitCommEvent(hComm, &fdwCommMask, &OverLapped))
	{
		if (GetLastError() == ERROR_IO_PENDING)
		{
			if (WaitForSingleObject(OverLapped.hEvent, (DWORD)msec) != WAIT_OBJECT_0)
				return FALSE;
		}
	}
	CloseHandle(OverLapped.hEvent);
	if ((fdwCommMask & EV_RXCHAR) != EV_RXCHAR)
		return FALSE;
	return TRUE;
}