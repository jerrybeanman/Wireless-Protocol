#include "Physical_Read.h"

// TODO:: In Wait_For_Packet, need to go to Wait state

HANDLE hComm;
HANDLE hRead_Lock = CreateMutex(NULL, FALSE, READ_LOCK);

//	Initialize hComm
VOID Initialize_Serial_Port()
{
	Error_Check((hComm = CreateFile(lpszCommName, 
		GENERIC_READ | GENERIC_WRITE, 
		0,
		NULL, 
		OPEN_EXISTING, 
		FILE_FLAG_OVERLAPPED,
		NULL)) == INVALID_HANDLE_VALUE ?
		ERR_INIT_COMM : NO_ERR);
}

// Create read thread
VOID Initialize_Read()
{
	Error_Check((rThread = CreateThread(NULL, 0, Read_Idle, NULL , 0, &rThreadId)) == NULL ?
		ERR_READ_THREAD : NO_ERR);
}

// Engine read state
DWORD WINAPI Read_Idle(LPVOID lpvoid)
{	
	DWORD total_bytes_read;
	// til the end of time
	while (1)
	{
		// Idle state waiting
		char *str = Wait_For_Input();
		/*char *str;
		if (!Wait_For_Data(&str, 1, &total_bytes_read, INFINITE)) { continue; }*/
		
			// If we get an ENQ | DC2
		if (Evaluate_Input(str[0]))
		{
			// Send a DC1 | ACK
			Send_Response();
			// Now we wait for the packet to come, and validate it
			Wait_For_Packet();
		}
	}
	return 0;
}

VOID Send_Response()
{
	char  response[1];
	response[0] = weHavePriority ? DC1 : ACK;
	OutputDebugString("Sending a response\n");
	Send(response, sizeof(response), hRead_Lock);
}

// use event driven approach to wait for ENQ | DC2
LPSTR Wait_For_Input()
{
	COMSTAT cs;
	char str[1];
	OVERLAPPED ovRead = { NULL };
	ovRead.hEvent = CreateEvent(NULL, FALSE, FALSE, EV_OVREAD);
	//	Set listener to a character
	Error_Check(!SetCommMask(hComm, EV_RXCHAR) ? ERR_COMMMASK : NO_ERR);
	DWORD read_byte, dwEvent, dwError;
	if (WaitCommEvent(hComm, &dwEvent, NULL))
	{
		// Clear Comm Port
		ClearCommError(hComm, &dwError, &cs);
		if ((dwEvent & EV_RXCHAR) && cs.cbInQue)
		{
			if (!ReadFile(hComm, str, sizeof(str), &read_byte, &ovRead))
				Output_GetLastError();
		}
	}
	if (dwEvent == 0)
		ExitThread(rThreadId);
	PurgeComm(hComm, PURGE_RXCLEAR | PURGE_TXCLEAR);
	CloseHandle(ovRead.hEvent);
	return str;
}


BOOL Evaluate_Input(CHAR c)
{

	if (c != ENQ && c != DC2)
		return FALSE;
	if (c == ENQ)
	{
		OutputDebugString("Got an Enq\n");
		senderHasPriority = FALSE;
		return TRUE;
	}
	else if (c == DC2)
	{
		OutputDebugString("Got an DC2\n");
		senderHasPriority = TRUE;
		return TRUE;
	}
	return FALSE;
}

VOID Wait_For_Packet()
{
	std::string packet;
	BOOL  packet_recieved = FALSE;
	while (!packet_recieved)
	{
		char *str;
		OutputDebugString("Waiting for packet\n");
		// If timeout
		if (!Wait_For_Data(&str, 1, 2000))
		{
			// Check priority state
			// go back to idle or wait state
			OutputDebugString("Going back to idle\n");
			return;
		}
		packet += str[0];
		if (str[0] == SOH)
			OutputDebugString("Got SOH\n");
		if (str[0] == SYN0)
			OutputDebugString("Got SYN0\n");
		if (str[0] == EOT)
		{
			OutputDebugString("Got EOT\n");
			// if packet good, we send an ACK | DC1, else we continue to wait
			if (Check_Packet(packet.c_str()))
			{
				OutputDebugString("Valid Packet, Read Successfull!\n");
				packet_recieved = TRUE;
			}
			else
				OutputDebugString("Invalid Packet\n");
		}
	}
	Send_Response();
}

// Validate packet
BOOL Check_Packet(const char *packet)
{
	size_t i;
	std::string message;
	OutputDebugString("In packet check\n");
	if (packet[0] == SOH && (packet[1] == SYN1 || packet[1] == SYN0))
	{
		if (packet[1] == prev_sync_received)
		{
			return FALSE;
		}
		for (i = 4; i < 516; i++)
		{
			if (packet[i] == EOT)
			{
				/* 
				* signal end of transmission of file. de-packetize Read_Packets vector
				*	and build it into a file
				*/
				Read_Packets.clear();
				break;
			}
			message += packet[i];
		}
		OutputDebugString("Packet Message was: ");
		OutputDebugString(message.c_str());
		OutputDebugString("\n");
		Read_Packets.push_back(message);
		return TRUE;

	}
	return FALSE;
}
