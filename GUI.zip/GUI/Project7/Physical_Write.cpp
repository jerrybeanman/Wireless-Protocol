#include "Physical_Write.h"

HANDLE hWrite_Lock = CreateMutex(NULL, FALSE, WRITE_LOCK);
DWORD numTries_confirmLine = 0;
DWORD numTries_sendPacket = 0;




// Enter send state in the protocol engine
VOID Initialize_Write(LPBYTE packet)
{

	Error_Check((wThread = CreateThread(NULL, 0, Transfer_Packet, (LPVOID)packet, 0, &wThreadId)) == NULL ?
		ERR_WRITE_THREAD : NO_ERR);
}

// Send state of the protocol engine
DWORD WINAPI Transfer_Packet(LPVOID packet)
{
	SetCommMask(hComm, RETURN_COMM_EVENT);
	WaitForSingleObject(hWrite_Lock, INFINITE);

	OutputDebugString("Starting confirm line loop\n");
	//Try to send an ENQ to confirm the line until we reach the maximum number of tries
	while (numTries_confirmLine < CONFIRM_LINE_MAX_TRIES) {
		//Send an ENQ to ask for the line
		ConfirmLine();

		//Wait for a response for the ENQ we sent
		char *response;
		if (!Wait_For_Data(&response, 1, 1000))
		{
			OutputDebugString("confirm line timeout\n");
			//Time'd out, increment counter and restart the loop to send the ENQ again
			numTries_confirmLine++;
			continue;
			
		}
		else if (response[0] == ACK || response[0] == DC1)
		{
			OutputDebugString("Got ACK or DC1 Backk\n");
			break;
		}
		else
		{
			OutputDebugString("not enq or dc.....its black magic\n");
		}
	}

	//If we hit the maximum number of tries, go back to Idle
	if (numTries_confirmLine >= CONFIRM_LINE_MAX_TRIES) {
		OutputDebugString("exceeded confirm line max tries\n");
		numTries_confirmLine = 0;
		ReleaseMutex(hWrite_Lock);
		Initialize_Read();
		return 0;
	}
	
	//Try to send the packet until we reach the maximum number of tries
	while (numTries_sendPacket < SEND_PACKET_MAX_TRIES) {
		//Send the packet
		OutputDebugString("Sending packet\n");
		SendPacket((char*)packet);

		//Wait for a response for the Packet we sent
		char *response = "";
		if (!Wait_For_Data(&response, 1, 1000))
		{
			//Time'd out, increment counter and restart the loop to send the packet again
			OutputDebugString("Exceeded max times for sending packet\n");
			numTries_sendPacket++;
			continue;
		}
		else if (response[0] == ACK || response[0] == DC1)
		{
			OutputDebugString("Got Ack or DC1 Back!\n");
			OutputDebugString("Packet Sent successfully\n");

			//Update the priority states based on the response
			senderHasPriority = response[0] == DC1 ? true : false;
			break;

			//Check Priorities
			//we are going back to Initialize_Read() everytime, regardless of priority for now
			/*if (weHavePriority && !senderHasPriority) {
				Initialize_Read();
			}
			else {

			}*/
		}
		else
		{
			OutputDebugString("aaaaaaaaaaaaaaa\n");
		}
	}

	//going back to wait/idle state
	ReleaseMutex(hWrite_Lock);
	Initialize_Read();
	return 0;
}

VOID ConfirmLine() {
	char str[1] = { ENQ };
	OutputDebugString("sending an ENQ\n");
	Send(str, sizeof(str), hWrite_Lock);
}

VOID SendPacket(char* str) {
	for (int i = 0; i < sizeof(str); i++)
	{
		char tmp[1] = { str[i] };
		Send(tmp, 1, hWrite_Lock);
		Sleep(40);
	}
}

VOID FlipSyncByte() {
	if (prev_sync_sent == SYN1) {
		prev_sync_sent = SYN0;
	}
	else {
		prev_sync_sent = SYN1;
	}
}


/* TEST FUNCTIONS ONLY */
VOID Test_Initialize_Write(LPBYTE packet)
{

	Error_Check((wThread = CreateThread(NULL, 0, Test_Transfer_Packet, (LPVOID)packet, 0, &wThreadId)) == NULL ?
		ERR_WRITE_THREAD : NO_ERR);
}

VOID Test_Initialize_Write2(LPBYTE packet)
{

	Error_Check((wThread = CreateThread(NULL, 0, Test_Transfer_Packet2, (LPVOID)packet, 0, &wThreadId)) == NULL ?
		ERR_WRITE_THREAD : NO_ERR);
}


DWORD WINAPI Test_Transfer_Packet(LPVOID packet)
{
	SetCommMask(hComm, RETURN_COMM_EVENT);
	WaitForSingleObject(hWrite_Lock, INFINITE);
	Test_Send_Enq();
	ReleaseMutex(hWrite_Lock);
	Initialize_Read();
	return 0;
}

DWORD WINAPI Test_Transfer_Packet2(LPVOID packet)
{
	Test_Transfer_Packet();
	return 0;
}
