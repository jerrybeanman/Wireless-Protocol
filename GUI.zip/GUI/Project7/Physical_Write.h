#ifndef PHYSICAL_WRITE_H
#define PHYSICAL_WRITE_H
#include "Global.h"
VOID Initialize_Write(LPBYTE packet);

DWORD WINAPI Transfer_Packet(LPVOID packet);
VOID Send(char* msg, DWORD size, HANDLE lock);
VOID ConfirmLine();
VOID SendPacket(char* str);
VOID FlipSyncByte();

//TEST FUNCTIONS ONLY
VOID Test_Initialize_Write(LPBYTE packet);
DWORD WINAPI Test_Transfer_Packet(LPVOID packet);
VOID Test_Initialize_Write2(LPBYTE packet);
DWORD WINAPI Test_Transfer_Packet2(LPVOID packet);

#endif