#include "Session.h"

void terminateSession() {
	PostQuitMessage(0);
}
