#include "Global.h"

#ifndef SESSION_H
#define SESSION_H


void terminateSession();

#endif
