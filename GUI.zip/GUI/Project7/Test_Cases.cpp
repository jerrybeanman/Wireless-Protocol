#include "Test_Cases.h"
VOID Test_Send_Enq()
{
	char str[1] = { ENQ };
	OutputDebugString("sending an ENQ\n");
	Send(str, sizeof(str), hWrite_Lock);
	DWORD total_bytes_read;
	char *response;
	if (!Wait_For_Data(&response, 1, 1000))
	{
		//Handle Timeout
	}else
	if (response[0] == ACK)
	{
		OutputDebugString("Got ACK Backk\n");
		Test_Send_Packet();
	}else
	if (response[0] == DC1)
	{
		OutputDebugString("Got DC Backk\n");
		Test_Send_Packet();
	}
	else
		OutputDebugString("not enq or dc.....its black magic\n");
}

VOID Test_Send_Packet()
{
	OutputDebugString("Sending packet!\n");
	char str[10] = { SOH, SYN0, DC1, DC1, 'a', 'b', 'c', 'd', 'e', EOT };
	for (int i = 0; i < sizeof(str); i++)
	{
		char tmp[1] = { str[i] };
		Send(tmp, 1, hWrite_Lock);
		Sleep(40);
	}
	//Send(str, sizeof(str), hWrite_Lock);
	//DWORD total_bytes_read;
	char *response = "";
	if (!Wait_For_Data(&response, 1, 1000))
	{
		//Handle Timeout
	}else if (*response == ACK)
	{
		OutputDebugString("Got Ack Back!\n");
		OutputDebugString("Packet Sent successfully\n");
	}else if (response[0] == DC1)
	{
		OutputDebugString("Packet Sent successfully, Got DC Backk\n");
	}
	else
		OutputDebugString("aaaaaaaaaaaaaaa\n");
}

VOID Test_Transfer_Packet() {
	OutputDebugString("Sending packet v2!\n");
	char str[10] = { SOH, SYN0, DC1, DC1, 'a', 'b', 'c', 'd', 'e', EOT };
	Transfer_Packet(str);
}

