#ifndef TEST_CASES
#define TEST_CASES
#include "Global.h"
VOID Test_Send_Enq();
VOID Test_Send_Packet();
VOID Test_Transfer_Packet();
#endif